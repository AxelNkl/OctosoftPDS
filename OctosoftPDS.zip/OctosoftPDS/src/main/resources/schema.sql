DROP TABLE IF EXISTS client;
CREATE TABLE client (
  id SERIAL PRIMARY KEY,
  mail VARCHAR(128) NOT NULL,
  mot_de_passe VARCHAR(20),
  nom VARCHAR(20),
  preferences VARCHAR(20),
  prenom VARCHAR(20),
  sexe VARCHAR(20)
);