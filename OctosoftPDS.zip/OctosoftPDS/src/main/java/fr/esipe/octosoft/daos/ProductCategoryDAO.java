package fr.esipe.octosoft.daos;

        import fr.esipe.octosoft.entities.Product;
        import org.springframework.data.repository.CrudRepository;
        import org.springframework.stereotype.Repository;

@Repository
public interface ProductCategoryDAO extends CrudRepository<Product, Integer> {
}
