package fr.esipe.octosoft.services;

import fr.esipe.octosoft.daos.StoreDAO;
import fr.esipe.octosoft.entities.Store;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StoreService {

    @Autowired
    private StoreDAO storeDAO;

    public Store createStore(Store store) {
        return storeDAO.save(store);
    }

    public void deleteStore(Store store) {
        storeDAO.delete(store);
    }

    public void updateStore(Store store) {
        storeDAO.save(store);
    }

    public Iterable<Store> readStore() {
        return storeDAO.findAll();
    }

    public Store searchStore(Store store) {
        return storeDAO.findById(store.getId()).get();
    }
}
