package fr.esipe.octosoft.daos;

import fr.esipe.octosoft.entities.Store;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StoreDAO extends CrudRepository<Store, Integer> {
}

