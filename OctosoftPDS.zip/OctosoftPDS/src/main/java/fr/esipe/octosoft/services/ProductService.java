package fr.esipe.octosoft.services;


import fr.esipe.octosoft.daos.ProductDAO;
import fr.esipe.octosoft.entities.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

    @Autowired
    private ProductDAO productDAO;

    public Product createProduct(Product product) {
        return productDAO.save(product);
    }

    public void deleteProduct(Product product) {
        productDAO.delete(product);
    }

    public void updateProduct(Product product) {
        productDAO.save(product);
    }

    public Iterable<Product> readProduct() {
        return productDAO.findAll();
    }

    public Product searchProduct(Product product) {
        return productDAO.findById(product.getId()).get();
    }
}
