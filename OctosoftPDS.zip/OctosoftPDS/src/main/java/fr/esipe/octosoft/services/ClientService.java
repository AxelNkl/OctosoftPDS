package fr.esipe.octosoft.services;



import fr.esipe.octosoft.daos.ClientDAO;
import fr.esipe.octosoft.entities.Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Axel NKOLO
 */

@Service
public class ClientService {

    private static ClientDAO clientDAO;
    // private ClientFormToClient clientFormToClient;

    @Autowired
    public ClientService(ClientDAO clientDAO) {
        this.clientDAO = clientDAO;
    }

    public static List<String> getAllName() {
        List<Client> all = (List<Client>) clientDAO.findAll();
        List<String> response = new ArrayList<String>();
        for(Client p : all) response.add(p.getNom());
        return response;
    }

    public List<Client> listAll() {
        List<Client> clients = new ArrayList<>();
        clientDAO.findAll().forEach(clients::add);
        return clients;
    }


    public Client getById(Long id) {
        return clientDAO.findById(id).orElse(null);
    }


    public Client saveOrUpdate(Client client) {
        clientDAO.save(client);
        return client;
    }


    public void delete(Long id) {
        clientDAO.deleteById(id);
    }



    public Client saveOrUpdateClient(Client client) {
        Client savedClient = saveOrUpdate(client);
        return savedClient;
    }
}
