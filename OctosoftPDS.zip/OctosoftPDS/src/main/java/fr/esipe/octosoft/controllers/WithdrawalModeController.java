package fr.esipe.octosoft.controllers;

import fr.esipe.octosoft.entities.WithdrawalMode;
import fr.esipe.octosoft.services.WithdrawalModeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
class WithdrawalModeController {

    @Autowired
    private WithdrawalModeService withdrawalModeService;

    // @RequestMapping(value = {"/", "/index"})
    // public String home(Model model) {
    //    return "index";
    //  }


    // @GetMapping(value = "/withdrawalMode")
    //public Iterable<WithdrawalMode> withdrawalMethodList(){
    // return withdrawalModeService.withdrawalMethodList();

    // }

    /**
     *
     * @param
     * @return list of Withdrawal Mode
     * @throws
     */
    @GetMapping(value = "/withdrawalMode")
    public String withdrawalMethodList(Model model){

        model.addAttribute("withdrawalmodelist", withdrawalModeService.withdrawalMethodList());

        return "listWithdrawalMode";
    }

    /**
     *
     * @param id Id of the withdrawal mode
     * @return the withdrawal object
     * @throws Exception
     */
    @GetMapping(value = "/withdrawalMode/{id}")
    public WithdrawalMode displayWithdrawalMethod(@PathVariable int id ) throws Exception {
        return withdrawalModeService.displayWithdrawalMethod(id);
    }

    // @PostMapping("/withdrawalMode")
    // public ResponseEntity<Object> createWithdrawalMode(@RequestBody WithdrawalMode withdrawalMode) {
    //  WithdrawalMode savedWithdrawalMode = withdrawalModeService.createWithdrawalMode(withdrawalMode);

    // URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
    //      .buildAndExpand(savedWithdrawalMode.getId()).toUri();

    // return ResponseEntity.created(location).build();

    //}

    /**
     *
     * @param withdrawalMode
     * @param model
     * @return
     */
    @PostMapping(value = "/withdrawalMode")
    public String createWithdrawalMode(@ModelAttribute WithdrawalMode withdrawalMode,Model model) {
        WithdrawalMode savedWithdrawalMode = withdrawalModeService.createWithdrawalMode(withdrawalMode);


        return "redirect:/withdrawalMode";

    }

    /**
     *
     * @param id Id of the withdrawal mode
     */
    @DeleteMapping("/withdrawalMode/{id}")
    public void deleteWithdrawalMode(@PathVariable int id) {
        withdrawalModeService.deleteWithdrawalMode(id);
    }


}
