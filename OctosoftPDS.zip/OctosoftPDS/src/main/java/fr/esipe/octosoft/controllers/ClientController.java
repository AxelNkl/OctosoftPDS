package fr.esipe.octosoft.controllers;

import fr.esipe.octosoft.entities.Client;
import fr.esipe.octosoft.services.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


import fr.esipe.octosoft.services.HibernateSearchService;

import java.util.List;


/**
 * Created by Axel NKOLO
 */

@Controller
public class ClientController {

    private ClientService clientService;

    private HibernateSearchService searchservice;

    @RequestMapping(value = "/client/search", method = RequestMethod.GET)
    public String search(@RequestParam(value = "search", required = false) String q, Model model) {
        List<Client> searchResults = null;
        try {
            searchResults = searchservice.fuzzySearch(q);

        } catch (Exception ex) {
            // here you should handle unexpected errors
            // ...
            // throw ex;
        }
        model.addAttribute("search", searchResults);
        return "search";

    }

    @GetMapping("/clientName")
    public ResponseEntity<?> listName() {
        return new ResponseEntity<>(ClientService.getAllName(),
                HttpStatus.OK);
    }



    @Autowired
    public void setClientService(ClientService clientService) {
        this.clientService = clientService;
    }

    @RequestMapping("/client/result/{id}")
    public String getClienta(@PathVariable String id, Model model){
        model.addAttribute("client", clientService.getById(Long.valueOf(id)));
        return "result";
    }

    @RequestMapping({"/client/list", "/client"})
    public String listClients(Model model){
        model.addAttribute("clients", clientService.listAll());
        return "list";
    }

    @RequestMapping("/client/show/{id}")
    public String getClient(@PathVariable String id, Model model){
        model.addAttribute("client", clientService.getById(Long.valueOf(id)));
        return "show";
    }

    @RequestMapping("client/edit/{id}")
    public String edit(@PathVariable String id, Model model){
        Client client = clientService.getById(Long.valueOf(id));
        model.addAttribute("client", client);
        return "clientform";}

    @RequestMapping("/Client/createClient")
    public String newClient(Model model){
            model.addAttribute("client", new Client());
            return "clientform";
    }

    @RequestMapping(value = "/client", method = RequestMethod.POST)
    public String saveOrUpdateClient(@Valid Client client, BindingResult bindingResult){

        if(bindingResult.hasErrors()){
            return "clientform";
        }

        Client savedClient = clientService.saveOrUpdateClient(client);

        return "redirect:/client/show/" + savedClient.getId();
    }

    @RequestMapping("/client/delete/{id}")
    public String delete(@PathVariable String id){
        clientService.delete(Long.valueOf(id));
        return "redirect:/";
    }

    @RequestMapping("/client/result")
    public String resultClients(Model model){
        model.addAttribute("clients", clientService.listAll());
        return "result";
    }
}