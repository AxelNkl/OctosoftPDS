package fr.esipe.octosoft.repositories;

import fr.esipe.octosoft.entities.WithdrawalMode;
import org.springframework.data.repository.CrudRepository;

public interface WithdrawalModeDAO extends CrudRepository<WithdrawalMode, Integer> {

}
