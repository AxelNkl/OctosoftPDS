package fr.esipe.octosoft.daos;


import fr.esipe.octosoft.entities.Client;
import org.springframework.data.repository.CrudRepository;

/**
 *  Created by Axel NKOLO
 */

public interface ClientDAO extends CrudRepository<Client, Long> {
}
