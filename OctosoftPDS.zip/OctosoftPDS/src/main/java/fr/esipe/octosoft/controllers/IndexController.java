package fr.esipe.octosoft.controllers;

import fr.esipe.octosoft.entities.WithdrawalMode;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class IndexController {

    /**
     *
     * @return the index view
     */
    @RequestMapping(value = {"/index"})
    public String home() {
        return "index";
    }


    /**
     *
     * @param model
     * @return the create withdrawal Mode view
     */
    @RequestMapping(value ={"/newdrawalmode"})
    String createWithdrawalMode(Model model){
        model.addAttribute("WithdrawalMode", new WithdrawalMode());
        return "createWithdrawalMode";
    }

}
