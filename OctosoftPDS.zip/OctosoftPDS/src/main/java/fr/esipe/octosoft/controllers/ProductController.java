package fr.esipe.octosoft.controllers;


import fr.esipe.octosoft.entities.Product;

import fr.esipe.octosoft.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Product")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping("/createProduct")
    public String createProductView(Model model) {
        Product product = new Product();
        model.addAttribute("product", product);
        return "createProduct"; //ici on retourne la page HTML souhaitée
    }

    @PostMapping("/create")
    public String createProduct(@ModelAttribute Product product) {
        productService.createProduct(product);
        return "redirect:/"; //retour à la page d'accueil
    }

    @GetMapping("/deleteProduct")
    public String deleteProductView(Model model) {
        Product product = new Product();
        model.addAttribute("product", product);
        return "deleteProduct";
    }

    @PostMapping("/delete")
    public String deletePRoduct(@ModelAttribute Product product) {
        productService.deleteProduct(product);
        return ""; //retour à la page d'accueil
    }

    @GetMapping("/read")
    public String readProduct(Model model) {
        Iterable<Product> products = productService.readProduct();
        model.addAttribute("products", products);
        return "read";
    }

    @GetMapping("/updateProductFirst") //obtenir la vue
    public String updateProductView(Product product) {
        productService.updateProduct(product);
        return "updateView";
    }

    //@PostMapping("/updateViewSecond") //remplir les informations dans la vue
    //public String updateMagasinViewReturn

}
