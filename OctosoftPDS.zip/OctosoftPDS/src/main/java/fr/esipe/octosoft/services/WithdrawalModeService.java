package fr.esipe.octosoft.services;

import fr.esipe.octosoft.entities.WithdrawalMode;
import fr.esipe.octosoft.repositories.WithdrawalModeDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class WithdrawalModeService {

    @Autowired
    private WithdrawalModeDAO withdrawalModeDAO;

    public Iterable<WithdrawalMode> withdrawalMethodList(){
        return withdrawalModeDAO.findAll();

    }

    public WithdrawalMode displayWithdrawalMethod(int id ) throws Exception {
        Optional<WithdrawalMode> withdrawalMode = withdrawalModeDAO.findById(id);

        if (!withdrawalMode.isPresent())
            throw new Exception("id-" + id);

        return withdrawalMode.get();
    }

    public WithdrawalMode createWithdrawalMode(WithdrawalMode withdrawalMode) {
        return withdrawalModeDAO.save(withdrawalMode);
    }

    public void deleteWithdrawalMode(int id) {
        withdrawalModeDAO.deleteById(id);
    }
}


