package fr.esipe.octosoft.controllers;

import fr.esipe.octosoft.entities.Store;
import fr.esipe.octosoft.services.StoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/Stores")
public class StoreController {

    @Autowired
    private StoreService storeService;

    @GetMapping("/createView")
    public String createStoreView(Model model) {
        Store store = new Store();
        model.addAttribute("store", store);
        return "createView"; //ici on retourne la page HTML souhaitée
    }

    @PostMapping("/create")
    public String createStore(@ModelAttribute Store store) {
        storeService.createStore(store);
        return "redirect:/"; //retour à la page d'accueil
    }

    @GetMapping("/deleteView")
    public String deleteStoreView(Model model) {
        Store store = new Store();
        model.addAttribute("store", store);
        return "deleteView";
    }

    @PostMapping("/delete")
    public String deleteStore(@ModelAttribute Store store) {
        storeService.deleteStore(store);
        return ""; //retour à la page d'accueil
    }

    @GetMapping("/read")
    public String readStore(Model model) {
        Iterable<Store> stores = storeService.readStore();
        model.addAttribute("stores", stores);
        return "read";
    }

    @GetMapping("/updateViewFirst") //obtenir la vue
    public String updateStoreView(Store store) {
        storeService.updateStore(store);
        return "updateView";
    }

    //@PostMapping("/updateViewSecond") //remplir les informations dans la vue
    //public String updateMagasinViewReturn

}
